import pytest

@pytest.mark.case(id="TRACE-PROBE-001", category="trace-sanitization")
def test_authenticated_failure_trace(browser_page, browser_trace, base_url, admin_auth):
    page = browser_page
    page.goto(f"{base_url}/user/login", wait_until="domcontentloaded")
    page.locator("#user_name").fill(admin_auth[0])
    page.locator("#password").fill(admin_auth[1])
    page.get_by_role("button", name="Sign In").click()
    page.wait_for_url(lambda url: "/user/login" not in url, timeout=15000)
    browser_trace.start_after_login()
    page.goto(f"{base_url}/user", wait_until="domcontentloaded")
    pytest.fail("intentional diagnostic failure containing local credential: " + admin_auth[1])

@pytest.mark.case(id="SKIP-PROBE-001", category="report-compatibility")
@pytest.mark.skip(reason="intentional setup-skip compatibility probe")
def test_setup_skip_report_shape():
    pass
